python genlatex.py
pdflatex invitation.tex